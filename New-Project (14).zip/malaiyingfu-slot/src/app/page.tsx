317|    ctx.font = "700 10px system-ui, -apple-system, Segoe UI, Roboto";
325|      const spacing = 11;
331|      ctx.lineWidth = 2;
